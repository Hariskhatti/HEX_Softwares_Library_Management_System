package hello.security.main;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HexSoftwaresLibraryManagementSyetemApplicationTests {

	@Test
	void contextLoads() {
	}

}
