package hello.security.main;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import hello.security.main.entities.BookEntity;
import hello.security.main.entities.MemberEntity;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@Tag(name = "HEX Softwares", description = "Task 2 Library Management System")
public class LibraryController {

    @Autowired
    ServiceClass sClass;

    // add book
    @Operation(summary = "A - Add Book")
    @PostMapping("/library/addBooks")
    public String addBook(@RequestBody BookEntity book) {
        sClass.addBook(book);
        return "Book added successfully";
    }

    // add member
    @Operation(summary = "B - Add Member")
    @PostMapping("/library/addMember")
    public String addMember(@RequestBody MemberEntity member) {
        sClass.addMember(member);
        return "Member added successfully";
    }

    // get available books
    @Operation(summary = "C - View Available Books")
    @GetMapping("/library/available-books")
    public Object availableBooks() {
        return sClass.getAvailableBooks();
    }

    // issue book
    @Operation(summary = "D - Issue Book")
    @PostMapping("/library/issue")
    public String issueBook(@RequestParam String bookTitle,
                            @RequestParam String memberName) {
        sClass.issueBook(bookTitle, memberName);
        return "Book issued successfully";
    }

    // view issued books
    @Operation(summary = "E - View Issued Books")
    @GetMapping("/library/issued-books")
    public Object issuedBooks() {
        return sClass.getIssuedBooks();
    }

    // member borrowed books
    @Operation(summary = "F - View Member Borrowed Books")
    @GetMapping("/library/member-books")
    public Object memberBooks(@RequestParam String memberName) {
        return sClass.getBooksByMember(memberName);
    }

    //  return book
    @Operation(summary = "G - Return Book")
    @PostMapping("/library/return")
    public String returnBook(@RequestParam String bookTitle,
                             @RequestParam String memberName) {
        sClass.returnBook(bookTitle, memberName);
        return "Book returned successfully";
    }
}