package hello.security.main;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import hello.security.main.entities.BookEntity;
import hello.security.main.entities.LibraryEntity;
import hello.security.main.entities.MemberEntity;
import hello.security.main.repository.BookRepository;
import hello.security.main.repository.LibraryRepository;
import hello.security.main.repository.MemberRepository;

@Service
public class ServiceClass {

    @Autowired
    BookRepository bookRepository;

    @Autowired
    MemberRepository memberRepository;

    @Autowired
    LibraryRepository libraryRepository;

    //  add book
    public BookEntity addBook(BookEntity book) {
        book.setIssued(false);
        return bookRepository.save(book);
    }

    // add member
    public MemberEntity addMember(MemberEntity member) {

        if (member.getName() == null || member.getName().isEmpty()) {
            throw new IllegalArgumentException("Name is required");
        }

        if (member.getEmail() == null || member.getEmail().isEmpty()) {
            throw new IllegalArgumentException("Email is required");
        }

        return memberRepository.save(member);
    }

    //  issue book 
    public void issueBook(String bookTitle, String memberName) {

        BookEntity book = bookRepository.findByTitle(bookTitle);
        if (book == null) {
            throw new RuntimeException("Book not found with title: " + bookTitle);
        }

        MemberEntity member = memberRepository.findByName(memberName);
        if (member == null) {
            throw new RuntimeException("Member not found with name: " + memberName);
        }

        if (book.isIssued()) {
            throw new IllegalArgumentException("Book already issued");
        }

        book.setIssued(true);

        LibraryEntity record = new LibraryEntity();
        record.setBook(book);
        record.setMember(member);
        record.setIssueDate(java.time.LocalDate.now());

        bookRepository.save(book);
        libraryRepository.save(record);
    }
    
    //  return book
    public void returnBook(String bookTitle, String memberName) {

        BookEntity book = bookRepository.findByTitle(bookTitle);
        if (book == null) {
            throw new RuntimeException("Invalid book title");
        }

        MemberEntity member = memberRepository.findByName(memberName);
        if (member == null) {
            throw new RuntimeException("Invalid member name");
        }

        LibraryEntity record =
                libraryRepository.findByBookAndMemberAndReturnDateIsNull(book, member);

        if (record == null) {
            throw new RuntimeException("No issued book found for this member");
        }

        record.setReturnDate(java.time.LocalDate.now());
        book.setIssued(false);

        libraryRepository.save(record);
        bookRepository.save(book);
    }

    //  issued books with member + date
    public List<LibraryEntity> getIssuedBooks() {
        return libraryRepository.findByReturnDateIsNull();
    }
    
    //get available books
    public List<BookEntity> getAvailableBooks() {
        return bookRepository.findByIsIssuedFalse();
    }

    //  member borrowed books
    public List<LibraryEntity> getBooksByMember(String memberName) {

        MemberEntity member = memberRepository.findByName(memberName);

        return libraryRepository.findByMemberAndReturnDateIsNull(member);
    }
}