package hello.security.main.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import hello.security.main.entities.BookEntity;
@Repository
public interface BookRepository extends JpaRepository<BookEntity, Long>{
	BookEntity findByTitle(String title);
	List<BookEntity> findByIsIssuedFalse();

}
