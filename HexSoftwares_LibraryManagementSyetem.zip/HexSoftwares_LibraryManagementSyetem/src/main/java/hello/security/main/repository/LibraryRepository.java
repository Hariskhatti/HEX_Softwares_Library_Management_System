package hello.security.main.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import hello.security.main.entities.BookEntity;
import hello.security.main.entities.LibraryEntity;
import hello.security.main.entities.MemberEntity;
@Repository
public interface LibraryRepository extends JpaRepository<LibraryEntity, Long> {
	LibraryEntity findByBookAndMemberAndReturnDateIsNull(BookEntity book, MemberEntity member);

	List<LibraryEntity> findByReturnDateIsNull();

	List<LibraryEntity> findByMemberAndReturnDateIsNull(MemberEntity member);
}
