package hello.security.main;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HexSoftwaresLibraryManagementSyetemApplication {

	public static void main(String[] args) {
		SpringApplication.run(HexSoftwaresLibraryManagementSyetemApplication.class, args);
	}

}