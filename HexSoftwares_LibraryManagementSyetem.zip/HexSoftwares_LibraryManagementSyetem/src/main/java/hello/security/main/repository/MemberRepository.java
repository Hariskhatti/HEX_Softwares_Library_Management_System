package hello.security.main.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import hello.security.main.entities.MemberEntity;
@Repository
public interface MemberRepository extends JpaRepository<MemberEntity, Long>{
	MemberEntity findByName(String name);
}
